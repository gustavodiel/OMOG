#include "../include/Application.hpp"

int main()
{
    auto app = new Application(1200, 1200);

    app->Start();

    return 0;
}