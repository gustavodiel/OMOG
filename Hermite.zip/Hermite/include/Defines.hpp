//
// Created by d on 18/03/19.
//

#ifndef DEFINES_HPP
#define DEFINES_HPP

#define MAP_TYPE int_fast32_t
#define POSITION_TYPE int_fast32_t

#endif // DEFINES_HPP